import { useState, useCallback } from 'react';
import { View, Text, TextInput, TouchableOpacity, ScrollView, Alert, Linking } from 'react-native';
import { Image } from 'expo-image';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Search, Book, Star, Calendar, User, ExternalLink } from 'lucide-react-native';

export default function BooksScreen() {
  const insets = useSafeAreaInsets();
  const [searchQuery, setSearchQuery] = useState('');
  const [searchType, setSearchType] = useState('title');
  const [books, setBooks] = useState([]);
  const [loading, setLoading] = useState(false);

  const searchBooks = useCallback(async () => {
    if (!searchQuery.trim()) return;
    
    setLoading(true);
    
    try {
      let url = 'https://openlibrary.org/search.json?';
      
      switch (searchType) {
        case 'title':
          url += `title=${encodeURIComponent(searchQuery)}`;
          break;
        case 'author':
          url += `author=${encodeURIComponent(searchQuery)}`;
          break;
        case 'subject':
          url += `subject=${encodeURIComponent(searchQuery)}`;
          break;
        case 'isbn':
          url += `isbn=${encodeURIComponent(searchQuery)}`;
          break;
        default:
          url += `q=${encodeURIComponent(searchQuery)}`;
      }
      
      url += '&limit=20';
      
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`Search failed: ${response.status} ${response.statusText}`);
      }
      
      const data = await response.json();
      setBooks(data.docs || []);
    } catch (err) {
      console.error(err);
      Alert.alert('Error', 'Failed to search books. Please try again.');
    } finally {
      setLoading(false);
    }
  }, [searchQuery, searchType]);

  const getCoverUrl = (book) => {
    if (book.cover_i) {
      return `https://covers.openlibrary.org/b/id/${book.cover_i}-M.jpg`;
    }
    return null;
  };

  const openBookDetails = async (book) => {
    if (book.key) {
      const url = `https://openlibrary.org${book.key}`;
      const supported = await Linking.canOpenURL(url);
      if (supported) {
        await Linking.openURL(url);
      }
    }
  };

  const quickSearch = (term, type = 'subject') => {
    setSearchType(type);
    setSearchQuery(term);
  };

  return (
    <View style={{ flex: 1, backgroundColor: '#f0f9ff' }}>
      <StatusBar style="dark" />
      
      {/* Header */}
      <View style={{ paddingTop: insets.top + 20, paddingHorizontal: 20 }}>
        <View style={{ alignItems: 'center', marginBottom: 20 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 8 }}>
            <Book color="#2563eb" size={32} />
            <Text style={{ fontSize: 28, fontWeight: 'bold', color: '#1f2937', marginLeft: 12 }}>
              Book Finder
            </Text>
          </View>
          <Text style={{ fontSize: 16, color: '#6b7280', textAlign: 'center' }}>
            Discover your next great read, Alex!
          </Text>
          <Text style={{ fontSize: 12, color: '#2563eb', marginTop: 4 }}>
            Perfect for college research and leisure reading
          </Text>
        </View>

        {/* Search Type Selector */}
        <ScrollView 
          horizontal 
          showsHorizontalScrollIndicator={false}
          style={{ marginBottom: 16 }}
          contentContainerStyle={{ paddingRight: 20 }}
        >
          {[
            { key: 'title', label: 'Title' },
            { key: 'author', label: 'Author' },
            { key: 'subject', label: 'Subject' },
            { key: 'isbn', label: 'ISBN' }
          ].map((type) => (
            <TouchableOpacity
              key={type.key}
              onPress={() => setSearchType(type.key)}
              style={{
                paddingHorizontal: 16,
                paddingVertical: 8,
                backgroundColor: searchType === type.key ? '#2563eb' : '#e5e7eb',
                borderRadius: 20,
                marginRight: 8,
              }}
            >
              <Text style={{
                color: searchType === type.key ? 'white' : '#374151',
                fontWeight: '500',
                fontSize: 14,
              }}>
                {type.label}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        {/* Search Input */}
        <View style={{
          flexDirection: 'row',
          backgroundColor: 'white',
          borderRadius: 12,
          paddingHorizontal: 16,
          paddingVertical: 12,
          marginBottom: 16,
          shadowColor: '#000',
          shadowOffset: { width: 0, height: 2 },
          shadowOpacity: 0.1,
          shadowRadius: 4,
          elevation: 3,
        }}>
          <Search color="#9ca3af" size={20} style={{ marginRight: 12 }} />
          <TextInput
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholder={`Search by ${searchType}...`}
            style={{ flex: 1, fontSize: 16 }}
            onSubmitEditing={searchBooks}
          />
          <TouchableOpacity
            onPress={searchBooks}
            disabled={loading || !searchQuery.trim()}
            style={{
              backgroundColor: '#2563eb',
              paddingHorizontal: 16,
              paddingVertical: 8,
              borderRadius: 8,
              opacity: (loading || !searchQuery.trim()) ? 0.5 : 1,
            }}
          >
            <Text style={{ color: 'white', fontWeight: '500' }}>
              {loading ? 'Searching...' : 'Search'}
            </Text>
          </TouchableOpacity>
        </View>

        {/* Quick Search Suggestions */}
        <View style={{ marginBottom: 16 }}>
          <Text style={{ fontSize: 14, color: '#6b7280', textAlign: 'center', marginBottom: 8 }}>
            Popular searches for students:
          </Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center' }}>
            {['Psychology', 'Computer Science', 'History', 'Mathematics', 'Literature', 'Biology'].map((subject) => (
              <TouchableOpacity
                key={subject}
                onPress={() => quickSearch(subject, 'subject')}
                style={{
                  backgroundColor: '#dbeafe',
                  paddingHorizontal: 12,
                  paddingVertical: 6,
                  borderRadius: 16,
                  margin: 4,
                }}
              >
                <Text style={{ color: '#1d4ed8', fontSize: 12, fontWeight: '500' }}>
                  {subject}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      </View>

      {/* Results */}
      <ScrollView 
        style={{ flex: 1 }}
        contentContainerStyle={{ padding: 20, paddingBottom: insets.bottom + 20 }}
        showsVerticalScrollIndicator={false}
      >
        {books.length > 0 ? (
          <>
            <Text style={{ fontSize: 18, fontWeight: '600', color: '#1f2937', marginBottom: 16 }}>
              Found {books.length} books
            </Text>
            
            {books.map((book, index) => (
              <TouchableOpacity
                key={`${book.key}-${index}`}
                onPress={() => openBookDetails(book)}
                style={{
                  backgroundColor: 'white',
                  borderRadius: 12,
                  padding: 16,
                  marginBottom: 16,
                  shadowColor: '#000',
                  shadowOffset: { width: 0, height: 2 },
                  shadowOpacity: 0.1,
                  shadowRadius: 4,
                  elevation: 3,
                }}
              >
                <View style={{ flexDirection: 'row' }}>
                  {/* Book Cover */}
                  <View style={{
                    width: 80,
                    height: 120,
                    backgroundColor: '#f3f4f6',
                    borderRadius: 8,
                    marginRight: 16,
                    justifyContent: 'center',
                    alignItems: 'center',
                  }}>
                    {getCoverUrl(book) ? (
                      <Image
                        source={{ uri: getCoverUrl(book) }}
                        style={{ width: 80, height: 120, borderRadius: 8 }}
                        contentFit="cover"
                        transition={200}
                      />
                    ) : (
                      <Book color="#9ca3af" size={32} />
                    )}
                  </View>

                  {/* Book Info */}
                  <View style={{ flex: 1 }}>
                    <Text style={{
                      fontSize: 16,
                      fontWeight: '600',
                      color: '#1f2937',
                      marginBottom: 8,
                      lineHeight: 22,
                    }}>
                      {book.title}
                    </Text>

                    {book.author_name && (
                      <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 4 }}>
                        <User color="#6b7280" size={14} />
                        <Text style={{ color: '#6b7280', fontSize: 14, marginLeft: 6 }}>
                          {book.author_name.slice(0, 2).join(', ')}
                        </Text>
                      </View>
                    )}

                    {book.first_publish_year && (
                      <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 4 }}>
                        <Calendar color="#6b7280" size={14} />
                        <Text style={{ color: '#6b7280', fontSize: 14, marginLeft: 6 }}>
                          {book.first_publish_year}
                        </Text>
                      </View>
                    )}

                    {book.ratings_average && (
                      <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 8 }}>
                        <Star color="#fbbf24" size={14} />
                        <Text style={{ color: '#6b7280', fontSize: 14, marginLeft: 6 }}>
                          {book.ratings_average.toFixed(1)} ({book.ratings_count} ratings)
                        </Text>
                      </View>
                    )}

                    {book.subject && book.subject.length > 0 && (
                      <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginBottom: 8 }}>
                        {book.subject.slice(0, 3).map((subject, idx) => (
                          <View
                            key={idx}
                            style={{
                              backgroundColor: '#dbeafe',
                              paddingHorizontal: 8,
                              paddingVertical: 4,
                              borderRadius: 12,
                              marginRight: 4,
                              marginBottom: 4,
                            }}
                          >
                            <Text style={{ color: '#1d4ed8', fontSize: 12 }}>
                              {subject}
                            </Text>
                          </View>
                        ))}
                      </View>
                    )}

                    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                      <ExternalLink color="#2563eb" size={14} />
                      <Text style={{ color: '#2563eb', fontSize: 14, marginLeft: 6, fontWeight: '500' }}>
                        View Details
                      </Text>
                    </View>
                  </View>
                </View>
              </TouchableOpacity>
            ))}
          </>
        ) : searchQuery && !loading ? (
          <View style={{ alignItems: 'center', paddingTop: 60 }}>
            <Book color="#9ca3af" size={64} />
            <Text style={{ fontSize: 18, fontWeight: '500', color: '#6b7280', marginTop: 16, marginBottom: 8 }}>
              No books found
            </Text>
            <Text style={{ color: '#9ca3af', textAlign: 'center' }}>
              Try searching with different keywords or search type
            </Text>
          </View>
        ) : !searchQuery && books.length === 0 ? (
          <View style={{ alignItems: 'center', paddingTop: 60 }}>
            <Book color="#60a5fa" size={64} />
            <Text style={{ fontSize: 18, fontWeight: '500', color: '#374151', marginTop: 16, marginBottom: 8 }}>
              Ready to find your next book?
            </Text>
            <Text style={{ color: '#9ca3af', textAlign: 'center' }}>
              Search by title, author, subject, or ISBN to get started
            </Text>
          </View>
        ) : null}
      </ScrollView>
    </View>
  );
}