import { useState, useCallback } from 'react';
import { View, Text, TextInput, TouchableOpacity, ScrollView, Alert } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as Location from 'expo-location';
import { Search, Cloud, Sun, CloudRain, Thermometer, Wind, Droplets, Eye, MapPin } from 'lucide-react-native';

export default function WeatherScreen() {
  const insets = useSafeAreaInsets();
  const [searchQuery, setSearchQuery] = useState('');
  const [weatherData, setWeatherData] = useState(null);
  const [locationData, setLocationData] = useState(null);
  const [loading, setLoading] = useState(false);

  const searchWeather = useCallback(async () => {
    if (!searchQuery.trim()) return;
    
    setLoading(true);
    
    try {
      // First, get coordinates for the city using a geocoding service
      const geoResponse = await fetch(
        `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(searchQuery)}&count=1&language=en&format=json`
      );
      
      if (!geoResponse.ok) {
        throw new Error('Failed to find location');
      }
      
      const geoData = await geoResponse.json();
      if (!geoData.results || geoData.results.length === 0) {
        throw new Error('City not found');
      }
      
      const location = geoData.results[0];
      setLocationData(location);
      
      // Then get weather data using the coordinates
      const weatherResponse = await fetch(
        `https://api.open-meteo.com/v1/forecast?latitude=${location.latitude}&longitude=${location.longitude}&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,rain,showers,snowfall,weather_code,cloud_cover,pressure_msl,surface_pressure,wind_speed_10m,wind_direction_10m,wind_gusts_10m&daily=weather_code,temperature_2m_max,temperature_2m_min,apparent_temperature_max,apparent_temperature_min,sunrise,sunset,daylight_duration,sunshine_duration,uv_index_max,uv_index_clear_sky_max,precipitation_sum,rain_sum,showers_sum,snowfall_sum,precipitation_hours,precipitation_probability_max,wind_speed_10m_max,wind_gusts_10m_max,wind_direction_10m_dominant,shortwave_radiation_sum,et0_fao_evapotranspiration&timezone=auto`
      );
      
      if (!weatherResponse.ok) {
        throw new Error('Failed to fetch weather data');
      }
      
      const weather = await weatherResponse.json();
      setWeatherData(weather);
    } catch (err) {
      console.error(err);
      Alert.alert('Error', err.message || 'Failed to get weather data. Please try again.');
    } finally {
      setLoading(false);
    }
  }, [searchQuery]);

  const getCurrentLocation = async () => {
    setLoading(true);
    
    try {
      // Request location permission
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission denied', 'Permission to access location was denied');
        return;
      }

      // Get current position
      const location = await Location.getCurrentPositionAsync({});
      const { latitude, longitude } = location.coords;
      
      // Get weather data
      const weatherResponse = await fetch(
        `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,rain,showers,snowfall,weather_code,cloud_cover,pressure_msl,surface_pressure,wind_speed_10m,wind_direction_10m,wind_gusts_10m&daily=weather_code,temperature_2m_max,temperature_2m_min,apparent_temperature_max,apparent_temperature_min,sunrise,sunset,daylight_duration,sunshine_duration,uv_index_max,uv_index_clear_sky_max,precipitation_sum,rain_sum,showers_sum,snowfall_sum,precipitation_hours,precipitation_probability_max,wind_speed_10m_max,wind_gusts_10m_max,wind_direction_10m_dominant,shortwave_radiation_sum,et0_fao_evapotranspiration&timezone=auto`
      );
      
      if (weatherResponse.ok) {
        const weather = await weatherResponse.json();
        setWeatherData(weather);
        
        // Try to get location name from coordinates
        try {
          const geoResponse = await fetch(
            `https://geocoding-api.open-meteo.com/v1/search?latitude=${latitude}&longitude=${longitude}&count=1&language=en&format=json`
          );
          if (geoResponse.ok) {
            const geoData = await geoResponse.json();
            if (geoData.results && geoData.results.length > 0) {
              setLocationData(geoData.results[0]);
            } else {
              setLocationData({
                name: `${latitude.toFixed(2)}, ${longitude.toFixed(2)}`,
                latitude,
                longitude
              });
            }
          }
        } catch (e) {
          setLocationData({
            name: `${latitude.toFixed(2)}, ${longitude.toFixed(2)}`,
            latitude,
            longitude
          });
        }
      }
    } catch (err) {
      console.error(err);
      Alert.alert('Error', 'Failed to get current location weather');
    } finally {
      setLoading(false);
    }
  };

  const getWeatherIcon = (weatherCode, isDay = true) => {
    if (weatherCode <= 3) return <Sun color="#f59e0b" size={32} />;
    if (weatherCode <= 48) return <Cloud color="#6b7280" size={32} />;
    if (weatherCode <= 67) return <CloudRain color="#3b82f6" size={32} />;
    return <Cloud color="#6b7280" size={32} />;
  };

  const getWeatherDescription = (weatherCode) => {
    const descriptions = {
      0: 'Clear sky',
      1: 'Mainly clear',
      2: 'Partly cloudy',
      3: 'Overcast',
      45: 'Fog',
      48: 'Depositing rime fog',
      51: 'Light drizzle',
      53: 'Moderate drizzle',
      55: 'Dense drizzle',
      61: 'Slight rain',
      63: 'Moderate rain',
      65: 'Heavy rain',
      71: 'Slight snow fall',
      73: 'Moderate snow fall',
      75: 'Heavy snow fall',
      80: 'Slight rain showers',
      81: 'Moderate rain showers',
      82: 'Violent rain showers',
      95: 'Thunderstorm',
    };
    return descriptions[weatherCode] || 'Unknown';
  };

  return (
    <View style={{ flex: 1, backgroundColor: '#f0f9ff' }}>
      <StatusBar style="dark" />
      
      {/* Header */}
      <View style={{ paddingTop: insets.top + 20, paddingHorizontal: 20 }}>
        <View style={{ alignItems: 'center', marginBottom: 20 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 8 }}>
            <Cloud color="#0ea5e9" size={32} />
            <Text style={{ fontSize: 28, fontWeight: 'bold', color: '#1f2937', marginLeft: 12 }}>
              Weather Now
            </Text>
          </View>
          <Text style={{ fontSize: 16, color: '#6b7280', textAlign: 'center' }}>
            Current conditions for your outdoor adventures, Jamie!
          </Text>
          <Text style={{ fontSize: 12, color: '#0ea5e9', marginTop: 4 }}>
            Perfect for planning your next outdoor activity
          </Text>
        </View>

        {/* Search Input */}
        <View style={{
          flexDirection: 'row',
          backgroundColor: 'white',
          borderRadius: 12,
          paddingHorizontal: 16,
          paddingVertical: 12,
          marginBottom: 16,
          shadowColor: '#000',
          shadowOffset: { width: 0, height: 2 },
          shadowOpacity: 0.1,
          shadowRadius: 4,
          elevation: 3,
        }}>
          <Search color="#9ca3af" size={20} style={{ marginRight: 12 }} />
          <TextInput
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholder="Enter city name..."
            style={{ flex: 1, fontSize: 16 }}
            onSubmitEditing={searchWeather}
          />
          <TouchableOpacity
            onPress={searchWeather}
            disabled={loading || !searchQuery.trim()}
            style={{
              backgroundColor: '#0ea5e9',
              paddingHorizontal: 16,
              paddingVertical: 8,
              borderRadius: 8,
              marginRight: 8,
              opacity: (loading || !searchQuery.trim()) ? 0.5 : 1,
            }}
          >
            <Text style={{ color: 'white', fontWeight: '500' }}>
              {loading ? 'Loading...' : 'Search'}
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={getCurrentLocation}
            disabled={loading}
            style={{
              backgroundColor: '#e0f2fe',
              padding: 8,
              borderRadius: 8,
              opacity: loading ? 0.5 : 1,
            }}
          >
            <MapPin color="#0ea5e9" size={20} />
          </TouchableOpacity>
        </View>
      </View>

      {/* Results */}
      <ScrollView 
        style={{ flex: 1 }}
        contentContainerStyle={{ padding: 20, paddingBottom: insets.bottom + 20 }}
        showsVerticalScrollIndicator={false}
      >
        {weatherData && locationData ? (
          <>
            {/* Current Weather */}
            <View style={{
              backgroundColor: 'white',
              borderRadius: 16,
              padding: 20,
              marginBottom: 16,
              shadowColor: '#000',
              shadowOffset: { width: 0, height: 2 },
              shadowOpacity: 0.1,
              shadowRadius: 4,
              elevation: 3,
            }}>
              <View style={{ alignItems: 'center', marginBottom: 20 }}>
                <Text style={{ fontSize: 20, fontWeight: '600', color: '#1f2937', marginBottom: 4 }}>
                  {locationData.name}
                </Text>
                {locationData.country && (
                  <Text style={{ color: '#6b7280' }}>{locationData.country}</Text>
                )}
              </View>
              
              <View style={{ alignItems: 'center', marginBottom: 20 }}>
                {getWeatherIcon(weatherData.current.weather_code, weatherData.current.is_day)}
                <Text style={{ fontSize: 16, fontWeight: '500', color: '#374151', marginTop: 8 }}>
                  {getWeatherDescription(weatherData.current.weather_code)}
                </Text>
              </View>
              
              <View style={{ alignItems: 'center' }}>
                <Text style={{ fontSize: 48, fontWeight: 'bold', color: '#1f2937', marginBottom: 8 }}>
                  {Math.round(weatherData.current.temperature_2m)}°C
                </Text>
                <Text style={{ color: '#6b7280', fontSize: 16 }}>
                  Feels like {Math.round(weatherData.current.apparent_temperature)}°C
                </Text>
              </View>
            </View>

            {/* Weather Details */}
            <View style={{
              backgroundColor: 'white',
              borderRadius: 16,
              padding: 20,
              marginBottom: 16,
              shadowColor: '#000',
              shadowOffset: { width: 0, height: 2 },
              shadowOpacity: 0.1,
              shadowRadius: 4,
              elevation: 3,
            }}>
              <View style={{ flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' }}>
                <View style={{ alignItems: 'center', width: '48%', marginBottom: 20 }}>
                  <Wind color="#0ea5e9" size={24} />
                  <Text style={{ color: '#6b7280', fontSize: 12, marginTop: 4 }}>Wind Speed</Text>
                  <Text style={{ fontWeight: '600', fontSize: 16, marginTop: 2 }}>
                    {weatherData.current.wind_speed_10m} km/h
                  </Text>
                </View>
                
                <View style={{ alignItems: 'center', width: '48%', marginBottom: 20 }}>
                  <Droplets color="#3b82f6" size={24} />
                  <Text style={{ color: '#6b7280', fontSize: 12, marginTop: 4 }}>Humidity</Text>
                  <Text style={{ fontWeight: '600', fontSize: 16, marginTop: 2 }}>
                    {weatherData.current.relative_humidity_2m}%
                  </Text>
                </View>
                
                <View style={{ alignItems: 'center', width: '48%' }}>
                  <Thermometer color="#ef4444" size={24} />
                  <Text style={{ color: '#6b7280', fontSize: 12, marginTop: 4 }}>Pressure</Text>
                  <Text style={{ fontWeight: '600', fontSize: 16, marginTop: 2 }}>
                    {Math.round(weatherData.current.pressure_msl)} hPa
                  </Text>
                </View>
                
                <View style={{ alignItems: 'center', width: '48%' }}>
                  <Eye color="#6b7280" size={24} />
                  <Text style={{ color: '#6b7280', fontSize: 12, marginTop: 4 }}>Cloud Cover</Text>
                  <Text style={{ fontWeight: '600', fontSize: 16, marginTop: 2 }}>
                    {weatherData.current.cloud_cover}%
                  </Text>
                </View>
              </View>
            </View>

            {/* 7-Day Forecast */}
            <View style={{
              backgroundColor: 'white',
              borderRadius: 16,
              padding: 20,
              shadowColor: '#000',
              shadowOffset: { width: 0, height: 2 },
              shadowOpacity: 0.1,
              shadowRadius: 4,
              elevation: 3,
            }}>
              <Text style={{ fontSize: 18, fontWeight: '600', color: '#1f2937', marginBottom: 16 }}>
                7-Day Forecast
              </Text>
              
              {weatherData.daily.time.slice(0, 7).map((date, index) => (
                <View
                  key={date}
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    paddingVertical: 12,
                    borderBottomWidth: index < 6 ? 1 : 0,
                    borderBottomColor: '#f3f4f6',
                  }}
                >
                  <Text style={{ flex: 1, fontWeight: '500', color: '#374151' }}>
                    {index === 0 ? 'Today' : new Date(date).toLocaleDateString('en', { weekday: 'short' })}
                  </Text>
                  
                  <View style={{ marginRight: 16 }}>
                    {getWeatherIcon(weatherData.daily.weather_code[index], true)}
                  </View>
                  
                  <View style={{ alignItems: 'flex-end' }}>
                    <Text style={{ fontWeight: '600', color: '#1f2937' }}>
                      {Math.round(weatherData.daily.temperature_2m_max[index])}°
                    </Text>
                    <Text style={{ color: '#6b7280', fontSize: 12 }}>
                      {Math.round(weatherData.daily.temperature_2m_min[index])}°
                    </Text>
                  </View>
                </View>
              ))}
            </View>
          </>
        ) : (
          <View style={{ alignItems: 'center', paddingTop: 60 }}>
            <Cloud color="#60a5fa" size={64} />
            <Text style={{ fontSize: 18, fontWeight: '500', color: '#374151', marginTop: 16, marginBottom: 8 }}>
              Ready to check the weather?
            </Text>
            <Text style={{ color: '#9ca3af', textAlign: 'center' }}>
              Enter a city name or use your current location to get started
            </Text>
          </View>
        )}
      </ScrollView>
    </View>
  );
}