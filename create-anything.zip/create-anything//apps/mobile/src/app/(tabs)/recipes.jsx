import { useState, useCallback } from 'react';
import { View, Text, TextInput, TouchableOpacity, ScrollView, Alert, Linking } from 'react-native';
import { Image } from 'expo-image';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Search, ChefHat, Clock, Users, ExternalLink } from 'lucide-react-native';

export default function RecipesScreen() {
  const insets = useSafeAreaInsets();
  const [searchQuery, setSearchQuery] = useState('');
  const [searchType, setSearchType] = useState('ingredient');
  const [recipes, setRecipes] = useState([]);
  const [loading, setLoading] = useState(false);

  const searchRecipes = useCallback(async () => {
    if (!searchQuery.trim()) return;
    
    setLoading(true);
    
    try {
      let url = '';
      
      switch (searchType) {
        case 'ingredient':
          url = `https://www.themealdb.com/api/json/v1/1/filter.php?i=${encodeURIComponent(searchQuery)}`;
          break;
        case 'category':
          url = `https://www.themealdb.com/api/json/v1/1/filter.php?c=${encodeURIComponent(searchQuery)}`;
          break;
        case 'area':
          url = `https://www.themealdb.com/api/json/v1/1/filter.php?a=${encodeURIComponent(searchQuery)}`;
          break;
        case 'name':
          url = `https://www.themealdb.com/api/json/v1/1/search.php?s=${encodeURIComponent(searchQuery)}`;
          break;
        default:
          url = `https://www.themealdb.com/api/json/v1/1/search.php?s=${encodeURIComponent(searchQuery)}`;
      }
      
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`Search failed: ${response.status} ${response.statusText}`);
      }
      
      const data = await response.json();
      setRecipes(data.meals || []);
    } catch (err) {
      console.error(err);
      Alert.alert('Error', 'Failed to search recipes. Please try again.');
    } finally {
      setLoading(false);
    }
  }, [searchQuery, searchType]);

  const getRandomRecipes = useCallback(async () => {
    setLoading(true);
    
    try {
      const randomRecipes = [];
      // Get 8 random recipes for mobile
      for (let i = 0; i < 8; i++) {
        const response = await fetch('https://www.themealdb.com/api/json/v1/1/random.php');
        if (response.ok) {
          const data = await response.json();
          if (data.meals && data.meals[0]) {
            randomRecipes.push(data.meals[0]);
          }
        }
      }
      setRecipes(randomRecipes);
    } catch (err) {
      console.error(err);
      Alert.alert('Error', 'Failed to get random recipes. Please try again.');
    } finally {
      setLoading(false);
    }
  }, []);

  const openRecipe = async (recipe) => {
    let url = recipe.strSource;
    if (!url) {
      url = `https://www.themealdb.com/meal/${recipe.idMeal}`;
    }
    
    const supported = await Linking.canOpenURL(url);
    if (supported) {
      await Linking.openURL(url);
    }
  };

  const openYouTube = async (url) => {
    const supported = await Linking.canOpenURL(url);
    if (supported) {
      await Linking.openURL(url);
    }
  };

  const quickSearch = (term, type = 'ingredient') => {
    setSearchType(type);
    setSearchQuery(term);
  };

  return (
    <View style={{ flex: 1, backgroundColor: '#fff7ed' }}>
      <StatusBar style="dark" />
      
      {/* Header */}
      <View style={{ paddingTop: insets.top + 20, paddingHorizontal: 20 }}>
        <View style={{ alignItems: 'center', marginBottom: 20 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 8 }}>
            <ChefHat color="#ea580c" size={32} />
            <Text style={{ fontSize: 28, fontWeight: 'bold', color: '#1f2937', marginLeft: 12 }}>
              Recipe Ideas
            </Text>
          </View>
          <Text style={{ fontSize: 16, color: '#6b7280', textAlign: 'center' }}>
            Quick meal ideas for your busy schedule, Taylor!
          </Text>
          <Text style={{ fontSize: 12, color: '#ea580c', marginTop: 4 }}>
            Perfect for busy professionals who want to cook at home
          </Text>
        </View>

        {/* Search Type Selector */}
        <ScrollView 
          horizontal 
          showsHorizontalScrollIndicator={false}
          style={{ marginBottom: 16 }}
          contentContainerStyle={{ paddingRight: 20 }}
        >
          {[
            { key: 'ingredient', label: 'Ingredient' },
            { key: 'name', label: 'Recipe Name' },
            { key: 'category', label: 'Category' },
            { key: 'area', label: 'Cuisine' }
          ].map((type) => (
            <TouchableOpacity
              key={type.key}
              onPress={() => setSearchType(type.key)}
              style={{
                paddingHorizontal: 16,
                paddingVertical: 8,
                backgroundColor: searchType === type.key ? '#ea580c' : '#e5e7eb',
                borderRadius: 20,
                marginRight: 8,
              }}
            >
              <Text style={{
                color: searchType === type.key ? 'white' : '#374151',
                fontWeight: '500',
                fontSize: 14,
              }}>
                {type.label}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        {/* Search Input */}
        <View style={{
          flexDirection: 'row',
          backgroundColor: 'white',
          borderRadius: 12,
          paddingHorizontal: 16,
          paddingVertical: 12,
          marginBottom: 16,
          shadowColor: '#000',
          shadowOffset: { width: 0, height: 2 },
          shadowOpacity: 0.1,
          shadowRadius: 4,
          elevation: 3,
        }}>
          <Search color="#9ca3af" size={20} style={{ marginRight: 12 }} />
          <TextInput
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholder={searchType === 'ingredient' ? 'e.g., chicken, rice' : searchType === 'category' ? 'e.g., dessert, breakfast' : searchType === 'area' ? 'e.g., Italian, Mexican' : 'recipe name'}
            style={{ flex: 1, fontSize: 16 }}
            onSubmitEditing={searchRecipes}
          />
          <TouchableOpacity
            onPress={searchRecipes}
            disabled={loading || !searchQuery.trim()}
            style={{
              backgroundColor: '#ea580c',
              paddingHorizontal: 16,
              paddingVertical: 8,
              borderRadius: 8,
              opacity: (loading || !searchQuery.trim()) ? 0.5 : 1,
            }}
          >
            <Text style={{ color: 'white', fontWeight: '500' }}>
              {loading ? 'Searching...' : 'Search'}
            </Text>
          </TouchableOpacity>
        </View>

        {/* Random Recipes Button */}
        <TouchableOpacity
          onPress={getRandomRecipes}
          disabled={loading}
          style={{
            backgroundColor: '#fed7aa',
            paddingVertical: 12,
            borderRadius: 12,
            alignItems: 'center',
            marginBottom: 16,
            opacity: loading ? 0.5 : 1,
          }}
        >
          <Text style={{ color: '#c2410c', fontWeight: '600' }}>
            {loading ? 'Loading...' : '🎲 Get Random Recipe Ideas'}
          </Text>
        </TouchableOpacity>

        {/* Quick Suggestions */}
        <View style={{ marginBottom: 16 }}>
          <Text style={{ fontSize: 14, color: '#6b7280', textAlign: 'center', marginBottom: 8 }}>
            Quick ideas for busy professionals:
          </Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center' }}>
            {[
              { label: 'Chicken', type: 'ingredient' },
              { label: 'Pasta', type: 'ingredient' },
              { label: 'Rice', type: 'ingredient' },
              { label: 'Breakfast', type: 'category' },
              { label: 'Italian', type: 'area' },
              { label: 'Mexican', type: 'area' }
            ].map((item) => (
              <TouchableOpacity
                key={item.label}
                onPress={() => quickSearch(item.label, item.type)}
                style={{
                  backgroundColor: '#fed7aa',
                  paddingHorizontal: 12,
                  paddingVertical: 6,
                  borderRadius: 16,
                  margin: 4,
                }}
              >
                <Text style={{ color: '#c2410c', fontSize: 12, fontWeight: '500' }}>
                  {item.label}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      </View>

      {/* Results */}
      <ScrollView 
        style={{ flex: 1 }}
        contentContainerStyle={{ padding: 20, paddingBottom: insets.bottom + 20 }}
        showsVerticalScrollIndicator={false}
      >
        {recipes.length > 0 ? (
          <>
            <Text style={{ fontSize: 18, fontWeight: '600', color: '#1f2937', marginBottom: 16 }}>
              Found {recipes.length} recipes
            </Text>
            
            {recipes.map((recipe) => (
              <TouchableOpacity
                key={recipe.idMeal}
                onPress={() => openRecipe(recipe)}
                style={{
                  backgroundColor: 'white',
                  borderRadius: 12,
                  marginBottom: 16,
                  shadowColor: '#000',
                  shadowOffset: { width: 0, height: 2 },
                  shadowOpacity: 0.1,
                  shadowRadius: 4,
                  elevation: 3,
                  overflow: 'hidden',
                }}
              >
                {/* Recipe Image */}
                <View style={{ height: 200, backgroundColor: '#f3f4f6' }}>
                  <Image
                    source={{ uri: recipe.strMealThumb }}
                    style={{ width: '100%', height: 200 }}
                    contentFit="cover"
                    transition={200}
                  />
                </View>

                {/* Recipe Info */}
                <View style={{ padding: 16 }}>
                  <Text style={{
                    fontSize: 18,
                    fontWeight: '600',
                    color: '#1f2937',
                    marginBottom: 8,
                    lineHeight: 24,
                  }}>
                    {recipe.strMeal}
                  </Text>

                  <View style={{ flexDirection: 'row', marginBottom: 12 }}>
                    {recipe.strCategory && (
                      <View style={{
                        backgroundColor: '#fed7aa',
                        paddingHorizontal: 8,
                        paddingVertical: 4,
                        borderRadius: 12,
                        marginRight: 8,
                      }}>
                        <Text style={{ color: '#c2410c', fontSize: 12, fontWeight: '500' }}>
                          {recipe.strCategory}
                        </Text>
                      </View>
                    )}
                    {recipe.strArea && (
                      <View style={{
                        backgroundColor: '#dbeafe',
                        paddingHorizontal: 8,
                        paddingVertical: 4,
                        borderRadius: 12,
                      }}>
                        <Text style={{ color: '#1d4ed8', fontSize: 12, fontWeight: '500' }}>
                          {recipe.strArea}
                        </Text>
                      </View>
                    )}
                  </View>

                  {recipe.strInstructions && (
                    <Text style={{
                      color: '#6b7280',
                      fontSize: 14,
                      lineHeight: 20,
                      marginBottom: 12,
                    }}>
                      {recipe.strInstructions.substring(0, 100)}...
                    </Text>
                  )}

                  <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                      <ExternalLink color="#ea580c" size={16} />
                      <Text style={{ color: '#ea580c', fontSize: 14, marginLeft: 6, fontWeight: '500' }}>
                        View Recipe
                      </Text>
                    </View>

                    {recipe.strYoutube && (
                      <TouchableOpacity
                        onPress={() => openYouTube(recipe.strYoutube)}
                        style={{
                          backgroundColor: '#fee2e2',
                          paddingHorizontal: 8,
                          paddingVertical: 4,
                          borderRadius: 8,
                        }}
                      >
                        <Text style={{ color: '#dc2626', fontSize: 12, fontWeight: '500' }}>
                          📺 Video
                        </Text>
                      </TouchableOpacity>
                    )}
                  </View>
                </View>
              </TouchableOpacity>
            ))}
          </>
        ) : searchQuery && !loading ? (
          <View style={{ alignItems: 'center', paddingTop: 60 }}>
            <ChefHat color="#9ca3af" size={64} />
            <Text style={{ fontSize: 18, fontWeight: '500', color: '#6b7280', marginTop: 16, marginBottom: 8 }}>
              No recipes found
            </Text>
            <Text style={{ color: '#9ca3af', textAlign: 'center' }}>
              Try searching with different ingredients or terms
            </Text>
          </View>
        ) : !searchQuery && recipes.length === 0 && !loading ? (
          <View style={{ alignItems: 'center', paddingTop: 60 }}>
            <ChefHat color="#fb923c" size={64} />
            <Text style={{ fontSize: 18, fontWeight: '500', color: '#374151', marginTop: 16, marginBottom: 8 }}>
              Ready to cook something delicious?
            </Text>
            <Text style={{ color: '#9ca3af', textAlign: 'center' }}>
              Search by ingredients you have, or get random recipe inspiration!
            </Text>
          </View>
        ) : null}
      </ScrollView>
    </View>
  );
}