import { useState, useCallback, useEffect } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  Alert,
  Dimensions,
} from "react-native";
import { StatusBar } from "expo-status-bar";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import MapView, { Marker, PROVIDER_GOOGLE } from "react-native-maps";
import {
  Globe,
  RefreshCw,
  Filter,
  Info,
  AlertTriangle,
} from "lucide-react-native";

const { width, height } = Dimensions.get("window");

export default function EarthquakesScreen() {
  const insets = useSafeAreaInsets();
  const [earthquakes, setEarthquakes] = useState([]);
  const [loading, setLoading] = useState(false);
  const [timeRange, setTimeRange] = useState("all_day");
  const [minMagnitude, setMinMagnitude] = useState(0);
  const [showStats, setShowStats] = useState(false);

  const fetchEarthquakes = useCallback(async () => {
    setLoading(true);

    try {
      const urls = {
        all_hour:
          "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_hour.geojson",
        all_day:
          "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_day.geojson",
        all_week:
          "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_week.geojson",
        all_month:
          "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_month.geojson",
      };

      const response = await fetch(urls[timeRange]);
      if (!response.ok) {
        throw new Error(
          `Failed to fetch earthquake data: ${response.status} ${response.statusText}`,
        );
      }

      const data = await response.json();
      const filteredEarthquakes = data.features
        .filter((eq) => eq.properties.mag >= minMagnitude)
        .map((eq) => ({
          id: eq.id,
          magnitude: eq.properties.mag,
          place: eq.properties.place,
          time: new Date(eq.properties.time),
          coordinates: {
            latitude: eq.geometry.coordinates[1],
            longitude: eq.geometry.coordinates[0],
          },
          depth: eq.geometry.coordinates[2],
          url: eq.properties.url,
        }));

      setEarthquakes(filteredEarthquakes);
    } catch (err) {
      console.error(err);
      Alert.alert(
        "Error",
        "Failed to fetch earthquake data. Please try again.",
      );
    } finally {
      setLoading(false);
    }
  }, [timeRange, minMagnitude]);

  useEffect(() => {
    fetchEarthquakes();
  }, [fetchEarthquakes]);

  const getMagnitudeColor = (magnitude) => {
    if (magnitude >= 7) return "#dc2626"; // Red - Major
    if (magnitude >= 6) return "#ea580c"; // Orange - Strong
    if (magnitude >= 5) return "#f59e0b"; // Yellow - Moderate
    if (magnitude >= 4) return "#eab308"; // Light Yellow - Light
    if (magnitude >= 3) return "#84cc16"; // Green - Minor
    return "#6b7280"; // Gray - Micro
  };

  const getMagnitudeSize = (magnitude) => {
    if (magnitude >= 7) return 20;
    if (magnitude >= 6) return 16;
    if (magnitude >= 5) return 12;
    if (magnitude >= 4) return 8;
    if (magnitude >= 3) return 6;
    return 4;
  };

  const getStats = () => {
    if (earthquakes.length === 0) return null;

    const magnitudes = earthquakes.map((eq) => eq.magnitude);
    const avgMagnitude =
      magnitudes.reduce((sum, mag) => sum + mag, 0) / magnitudes.length;
    const maxMagnitude = Math.max(...magnitudes);
    const minMagnitudeValue = Math.min(...magnitudes);

    const severityGroups = {
      major: earthquakes.filter((eq) => eq.magnitude >= 7).length,
      strong: earthquakes.filter((eq) => eq.magnitude >= 6 && eq.magnitude < 7)
        .length,
      moderate: earthquakes.filter(
        (eq) => eq.magnitude >= 5 && eq.magnitude < 6,
      ).length,
      light: earthquakes.filter((eq) => eq.magnitude >= 4 && eq.magnitude < 5)
        .length,
      minor: earthquakes.filter((eq) => eq.magnitude >= 3 && eq.magnitude < 4)
        .length,
      micro: earthquakes.filter((eq) => eq.magnitude < 3).length,
    };

    return {
      total: earthquakes.length,
      avgMagnitude: avgMagnitude.toFixed(1),
      maxMagnitude: maxMagnitude.toFixed(1),
      minMagnitude: minMagnitudeValue.toFixed(1),
      severityGroups,
    };
  };

  const stats = getStats();

  return (
    <View style={{ flex: 1, backgroundColor: "#fef2f2" }}>
      <StatusBar style="dark" />

      {/* Header */}
      <View
        style={{
          paddingTop: insets.top + 20,
          paddingHorizontal: 20,
          paddingBottom: 16,
        }}
      >
        <View style={{ alignItems: "center", marginBottom: 16 }}>
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              marginBottom: 8,
            }}
          >
            <Globe color="#dc2626" size={32} />
            <Text
              style={{
                fontSize: 28,
                fontWeight: "bold",
                color: "#1f2937",
                marginLeft: 12,
              }}
            >
              Earthquakes
            </Text>
          </View>
          <Text style={{ fontSize: 16, color: "#6b7280", textAlign: "center" }}>
            Recent seismic activity worldwide, Casey!
          </Text>
          <Text style={{ fontSize: 12, color: "#dc2626", marginTop: 4 }}>
            Perfect for understanding earthquake patterns
          </Text>
        </View>

        {/* Controls */}
        <View style={{ flexDirection: "row", marginBottom: 16 }}>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            style={{ flex: 1 }}
            contentContainerStyle={{ paddingRight: 16 }}
          >
            {[
              { key: "all_hour", label: "Last Hour" },
              { key: "all_day", label: "Last Day" },
              { key: "all_week", label: "Last Week" },
              { key: "all_month", label: "Last Month" },
            ].map((range) => (
              <TouchableOpacity
                key={range.key}
                onPress={() => setTimeRange(range.key)}
                style={{
                  paddingHorizontal: 16,
                  paddingVertical: 8,
                  backgroundColor:
                    timeRange === range.key ? "#dc2626" : "#fee2e2",
                  borderRadius: 20,
                  marginRight: 8,
                }}
              >
                <Text
                  style={{
                    color: timeRange === range.key ? "white" : "#dc2626",
                    fontWeight: "500",
                    fontSize: 14,
                  }}
                >
                  {range.label}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>

          <TouchableOpacity
            onPress={() => setShowStats(!showStats)}
            style={{
              backgroundColor: showStats ? "#dc2626" : "#fee2e2",
              padding: 8,
              borderRadius: 8,
              marginLeft: 8,
            }}
          >
            <Info color={showStats ? "white" : "#dc2626"} size={20} />
          </TouchableOpacity>

          <TouchableOpacity
            onPress={fetchEarthquakes}
            disabled={loading}
            style={{
              backgroundColor: "#fee2e2",
              padding: 8,
              borderRadius: 8,
              marginLeft: 8,
              opacity: loading ? 0.5 : 1,
            }}
          >
            <RefreshCw color="#dc2626" size={20} />
          </TouchableOpacity>
        </View>

        {/* Magnitude Filter */}
        <View style={{ marginBottom: 16 }}>
          <Text style={{ fontSize: 14, color: "#6b7280", marginBottom: 8 }}>
            Minimum Magnitude: {minMagnitude}
          </Text>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ paddingRight: 20 }}
          >
            {[0, 2, 3, 4, 5, 6].map((mag) => (
              <TouchableOpacity
                key={mag}
                onPress={() => setMinMagnitude(mag)}
                style={{
                  paddingHorizontal: 12,
                  paddingVertical: 6,
                  backgroundColor: minMagnitude === mag ? "#dc2626" : "#fee2e2",
                  borderRadius: 16,
                  marginRight: 8,
                }}
              >
                <Text
                  style={{
                    color: minMagnitude === mag ? "white" : "#dc2626",
                    fontWeight: "500",
                    fontSize: 12,
                  }}
                >
                  {mag}+
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>
      </View>

      {/* Stats Panel */}
      {showStats && stats && (
        <View
          style={{
            backgroundColor: "white",
            marginHorizontal: 20,
            borderRadius: 12,
            padding: 16,
            marginBottom: 16,
            shadowColor: "#000",
            shadowOffset: { width: 0, height: 2 },
            shadowOpacity: 0.1,
            shadowRadius: 4,
            elevation: 3,
          }}
        >
          <Text
            style={{
              fontSize: 16,
              fontWeight: "600",
              color: "#1f2937",
              marginBottom: 12,
            }}
          >
            Statistics
          </Text>

          <View
            style={{
              flexDirection: "row",
              flexWrap: "wrap",
              justifyContent: "space-between",
            }}
          >
            <View style={{ alignItems: "center", marginBottom: 8 }}>
              <Text style={{ color: "#6b7280", fontSize: 12 }}>Total</Text>
              <Text style={{ fontWeight: "600", fontSize: 16 }}>
                {stats.total}
              </Text>
            </View>
            <View style={{ alignItems: "center", marginBottom: 8 }}>
              <Text style={{ color: "#6b7280", fontSize: 12 }}>Max Mag</Text>
              <Text style={{ fontWeight: "600", fontSize: 16 }}>
                {stats.maxMagnitude}
              </Text>
            </View>
            <View style={{ alignItems: "center", marginBottom: 8 }}>
              <Text style={{ color: "#6b7280", fontSize: 12 }}>Avg Mag</Text>
              <Text style={{ fontWeight: "600", fontSize: 16 }}>
                {stats.avgMagnitude}
              </Text>
            </View>
            <View style={{ alignItems: "center", marginBottom: 8 }}>
              <Text style={{ color: "#6b7280", fontSize: 12 }}>Min Mag</Text>
              <Text style={{ fontWeight: "600", fontSize: 16 }}>
                {stats.minMagnitude}
              </Text>
            </View>
          </View>

          {stats.severityGroups.major > 0 && (
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                marginTop: 8,
              }}
            >
              <AlertTriangle color="#dc2626" size={16} />
              <Text
                style={{
                  color: "#dc2626",
                  fontSize: 14,
                  marginLeft: 4,
                  fontWeight: "500",
                }}
              >
                {stats.severityGroups.major} Major (7.0+) earthquake
                {stats.severityGroups.major > 1 ? "s" : ""}
              </Text>
            </View>
          )}
        </View>
      )}

      {/* Map */}
      <View
        style={{ flex: 1, margin: 20, borderRadius: 12, overflow: "hidden" }}
      >
        <MapView
          provider={PROVIDER_GOOGLE}
          style={{ flex: 1 }}
          initialRegion={{
            latitude: 20,
            longitude: 0,
            latitudeDelta: 80,
            longitudeDelta: 80,
          }}
          mapType="terrain"
        >
          {earthquakes.map((earthquake) => (
            <Marker
              key={earthquake.id}
              coordinate={earthquake.coordinates}
              title={`Magnitude ${earthquake.magnitude.toFixed(1)}`}
              description={`${earthquake.place}\n${earthquake.time.toLocaleDateString()} ${earthquake.time.toLocaleTimeString()}`}
            >
              <View
                style={{
                  width: getMagnitudeSize(earthquake.magnitude),
                  height: getMagnitudeSize(earthquake.magnitude),
                  backgroundColor: getMagnitudeColor(earthquake.magnitude),
                  borderRadius: getMagnitudeSize(earthquake.magnitude) / 2,
                  borderWidth: 2,
                  borderColor: "white",
                  shadowColor: "#000",
                  shadowOffset: { width: 0, height: 2 },
                  shadowOpacity: 0.3,
                  shadowRadius: 3,
                  elevation: 5,
                }}
              />
            </Marker>
          ))}
        </MapView>
      </View>

      {/* Legend */}
      <View
        style={{
          backgroundColor: "white",
          marginHorizontal: 20,
          marginBottom: insets.bottom + 20,
          borderRadius: 12,
          padding: 16,
          shadowColor: "#000",
          shadowOffset: { width: 0, height: 2 },
          shadowOpacity: 0.1,
          shadowRadius: 4,
          elevation: 3,
        }}
      >
        <Text
          style={{
            fontSize: 14,
            fontWeight: "600",
            color: "#1f2937",
            marginBottom: 8,
          }}
        >
          Magnitude Scale
        </Text>
        <View
          style={{
            flexDirection: "row",
            flexWrap: "wrap",
            justifyContent: "space-between",
          }}
        >
          {[
            { min: 7, label: "7.0+ Major", color: "#dc2626" },
            { min: 6, label: "6.0+ Strong", color: "#ea580c" },
            { min: 5, label: "5.0+ Moderate", color: "#f59e0b" },
            { min: 4, label: "4.0+ Light", color: "#eab308" },
            { min: 3, label: "3.0+ Minor", color: "#84cc16" },
            { min: 0, label: "<3.0 Micro", color: "#6b7280" },
          ].map((item) => (
            <View
              key={item.min}
              style={{
                flexDirection: "row",
                alignItems: "center",
                marginBottom: 4,
              }}
            >
              <View
                style={{
                  width: 12,
                  height: 12,
                  backgroundColor: item.color,
                  borderRadius: 6,
                  marginRight: 6,
                }}
              />
              <Text style={{ color: "#6b7280", fontSize: 12 }}>
                {item.label}
              </Text>
            </View>
          ))}
        </View>

        {loading && (
          <Text
            style={{
              color: "#6b7280",
              fontSize: 12,
              textAlign: "center",
              marginTop: 8,
            }}
          >
            Loading earthquake data...
          </Text>
        )}
      </View>
    </View>
  );
}
