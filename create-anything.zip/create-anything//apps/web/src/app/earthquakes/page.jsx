import { useState, useCallback, useEffect } from "react";
import { Globe, Filter, Info, AlertTriangle, ArrowLeft } from "lucide-react";
import {
  APIProvider,
  Map,
  Marker,
  InfoWindow,
} from "@vis.gl/react-google-maps";

export default function EarthquakePage() {
  const [earthquakes, setEarthquakes] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [selectedEarthquake, setSelectedEarthquake] = useState(null);
  const [minMagnitude, setMinMagnitude] = useState(2.5);
  const [timeRange, setTimeRange] = useState("day");
  const [stats, setStats] = useState(null);

  const fetchEarthquakeData = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      let url = "";
      switch (timeRange) {
        case "hour":
          url =
            "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_hour.geojson";
          break;
        case "day":
          url =
            "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_day.geojson";
          break;
        case "week":
          url =
            "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_week.geojson";
          break;
        case "month":
          url =
            "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_month.geojson";
          break;
        default:
          url =
            "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_day.geojson";
      }

      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(
          `Failed to fetch earthquake data: ${response.status} ${response.statusText}`,
        );
      }

      const data = await response.json();
      const earthquakeList = data.features
        .filter((feature) => feature.properties.mag >= minMagnitude)
        .map((feature) => ({
          id: feature.id,
          magnitude: feature.properties.mag,
          place: feature.properties.place,
          time: new Date(feature.properties.time),
          depth: feature.geometry.coordinates[2],
          latitude: feature.geometry.coordinates[1],
          longitude: feature.geometry.coordinates[0],
          url: feature.properties.url,
          type: feature.properties.type,
          felt: feature.properties.felt,
          tsunami: feature.properties.tsunami,
        }));

      setEarthquakes(earthquakeList);

      // Calculate statistics
      const totalEarthquakes = earthquakeList.length;
      const avgMagnitude =
        earthquakeList.reduce((sum, eq) => sum + eq.magnitude, 0) /
        totalEarthquakes;
      const maxMagnitude = Math.max(
        ...earthquakeList.map((eq) => eq.magnitude),
      );
      const significantCount = earthquakeList.filter(
        (eq) => eq.magnitude >= 4.5,
      ).length;

      setStats({
        total: totalEarthquakes,
        average: avgMagnitude,
        maximum: maxMagnitude,
        significant: significantCount,
      });
    } catch (err) {
      console.error(err);
      setError("Failed to load earthquake data. Please try again.");
    } finally {
      setLoading(false);
    }
  }, [minMagnitude, timeRange]);

  useEffect(() => {
    fetchEarthquakeData();
  }, [fetchEarthquakeData]);

  const getMagnitudeColor = (magnitude) => {
    if (magnitude >= 7.0) return "#d32f2f"; // Red - Major
    if (magnitude >= 6.0) return "#f57c00"; // Orange - Strong
    if (magnitude >= 5.0) return "#fbc02d"; // Yellow - Moderate
    if (magnitude >= 4.0) return "#689f38"; // Green - Light
    return "#1976d2"; // Blue - Minor
  };

  const getMagnitudeSize = (magnitude) => {
    return Math.max(8, magnitude * 4);
  };

  const getMagnitudeLabel = (magnitude) => {
    if (magnitude >= 7.0) return "Major";
    if (magnitude >= 6.0) return "Strong";
    if (magnitude >= 5.0) return "Moderate";
    if (magnitude >= 4.0) return "Light";
    return "Minor";
  };

  const formatTime = (date) => {
    return date.toLocaleString();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-orange-100">
      <div className="flex flex-col h-screen">
        {/* Header */}
        <div className="bg-white shadow-sm p-4">
          <div className="container mx-auto">
            {/* Navigation */}
            <div className="mb-4">
              <a
                href="/"
                className="inline-flex items-center gap-2 text-red-600 hover:text-red-800 font-medium"
              >
                <ArrowLeft size={20} />
                Back to Apps
              </a>
            </div>

            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
              <div>
                <h1 className="text-2xl font-bold text-gray-800 flex items-center gap-3">
                  <Globe className="text-red-600" size={32} />
                  Earthquake Visualizer
                </h1>
                <p className="text-gray-600">
                  Real-time seismic activity visualization for Casey
                </p>
              </div>

              {/* Controls */}
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex items-center gap-2">
                  <label className="text-sm font-medium text-gray-700">
                    Time Range:
                  </label>
                  <select
                    value={timeRange}
                    onChange={(e) => setTimeRange(e.target.value)}
                    className="px-3 py-1 border border-gray-300 rounded focus:ring-2 focus:ring-red-500 focus:border-transparent text-sm"
                  >
                    <option value="hour">Past Hour</option>
                    <option value="day">Past Day</option>
                    <option value="week">Past Week</option>
                    <option value="month">Past Month</option>
                  </select>
                </div>

                <div className="flex items-center gap-2">
                  <label className="text-sm font-medium text-gray-700">
                    Min Magnitude:
                  </label>
                  <select
                    value={minMagnitude}
                    onChange={(e) =>
                      setMinMagnitude(parseFloat(e.target.value))
                    }
                    className="px-3 py-1 border border-gray-300 rounded focus:ring-2 focus:ring-red-500 focus:border-transparent text-sm"
                  >
                    <option value={1.0}>1.0+</option>
                    <option value={2.5}>2.5+</option>
                    <option value={4.0}>4.0+</option>
                    <option value={5.0}>5.0+</option>
                    <option value={6.0}>6.0+</option>
                  </select>
                </div>

                <button
                  onClick={fetchEarthquakeData}
                  disabled={loading}
                  className="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-sm"
                >
                  {loading ? "Loading..." : "Refresh"}
                </button>
              </div>
            </div>

            {/* Statistics */}
            {stats && (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
                <div className="bg-blue-100 rounded-lg p-3 text-center">
                  <div className="text-lg font-bold text-blue-800">
                    {stats.total}
                  </div>
                  <div className="text-sm text-blue-600">Total Earthquakes</div>
                </div>
                <div className="bg-green-100 rounded-lg p-3 text-center">
                  <div className="text-lg font-bold text-green-800">
                    {stats.average.toFixed(1)}
                  </div>
                  <div className="text-sm text-green-600">
                    Average Magnitude
                  </div>
                </div>
                <div className="bg-red-100 rounded-lg p-3 text-center">
                  <div className="text-lg font-bold text-red-800">
                    {stats.maximum.toFixed(1)}
                  </div>
                  <div className="text-sm text-red-600">Maximum Magnitude</div>
                </div>
                <div className="bg-orange-100 rounded-lg p-3 text-center">
                  <div className="text-lg font-bold text-orange-800">
                    {stats.significant}
                  </div>
                  <div className="text-sm text-orange-600">
                    Significant (4.5+)
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Error Message */}
        {error && (
          <div className="mx-4 mt-4 p-4 bg-red-100 border border-red-300 rounded-lg text-red-700 flex items-center gap-2">
            <AlertTriangle size={20} />
            {error}
          </div>
        )}

        {/* Map */}
        <div className="flex-1 relative">
          {process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY ? (
            <APIProvider apiKey={process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY}>
              <Map
                style={{ width: "100%", height: "100%" }}
                defaultCenter={{ lat: 20, lng: 0 }}
                defaultZoom={2}
                gestureHandling={"greedy"}
                disableDefaultUI={false}
                mapId="earthquake-map"
              >
                {earthquakes.map((earthquake) => (
                  <Marker
                    key={earthquake.id}
                    position={{
                      lat: earthquake.latitude,
                      lng: earthquake.longitude,
                    }}
                    onClick={() => setSelectedEarthquake(earthquake)}
                    title={`Magnitude ${earthquake.magnitude} - ${earthquake.place}`}
                  />
                ))}

                {selectedEarthquake && (
                  <InfoWindow
                    position={{
                      lat: selectedEarthquake.latitude,
                      lng: selectedEarthquake.longitude,
                    }}
                    onCloseClick={() => setSelectedEarthquake(null)}
                  >
                    <div className="p-2 max-w-xs">
                      <h3 className="font-bold text-gray-800 mb-2">
                        Magnitude {selectedEarthquake.magnitude}
                      </h3>
                      <div className="space-y-1 text-sm">
                        <p>
                          <strong>Location:</strong> {selectedEarthquake.place}
                        </p>
                        <p>
                          <strong>Time:</strong>{" "}
                          {formatTime(selectedEarthquake.time)}
                        </p>
                        <p>
                          <strong>Depth:</strong>{" "}
                          {selectedEarthquake.depth.toFixed(1)} km
                        </p>
                        <p>
                          <strong>Type:</strong>{" "}
                          {getMagnitudeLabel(selectedEarthquake.magnitude)}
                        </p>
                        {selectedEarthquake.felt && (
                          <p>
                            <strong>Felt reports:</strong>{" "}
                            {selectedEarthquake.felt}
                          </p>
                        )}
                        {selectedEarthquake.tsunami === 1 && (
                          <p className="text-red-600 font-medium">
                            ⚠️ Tsunami Warning
                          </p>
                        )}
                      </div>
                      {selectedEarthquake.url && (
                        <a
                          href={selectedEarthquake.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-block mt-2 text-blue-600 hover:text-blue-800 text-sm"
                        >
                          View Details →
                        </a>
                      )}
                    </div>
                  </InfoWindow>
                )}
              </Map>
            </APIProvider>
          ) : (
            <div className="flex items-center justify-center h-full bg-gray-100">
              <div className="text-center">
                <Globe className="mx-auto text-gray-400 mb-4" size={64} />
                <h3 className="text-xl font-medium text-gray-600 mb-2">
                  Map Unavailable
                </h3>
                <p className="text-gray-500">
                  Google Maps API key is required to display the map
                </p>
              </div>
            </div>
          )}

          {/* Legend */}
          <div className="absolute bottom-4 left-4 bg-white rounded-lg shadow-lg p-4">
            <h4 className="font-bold text-gray-800 mb-2">Magnitude Scale</h4>
            <div className="space-y-2">
              {[
                { min: 7.0, label: "Major", color: "#d32f2f" },
                { min: 6.0, label: "Strong", color: "#f57c00" },
                { min: 5.0, label: "Moderate", color: "#fbc02d" },
                { min: 4.0, label: "Light", color: "#689f38" },
                { min: 0, label: "Minor", color: "#1976d2" },
              ].map((item) => (
                <div key={item.min} className="flex items-center gap-2">
                  <div
                    className="w-4 h-4 rounded-full"
                    style={{ backgroundColor: item.color }}
                  ></div>
                  <span className="text-sm text-gray-600">
                    {item.min > 0 ? `${item.min}+` : "< 4.0"} - {item.label}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Loading Overlay */}
          {loading && (
            <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
              <div className="bg-white rounded-lg p-6 text-center">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-red-600 mx-auto mb-4"></div>
                <p className="text-gray-700">Loading earthquake data...</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
