import { useState, useCallback } from 'react';
import { Search, Book, Star, Calendar, User, ExternalLink, Home, ArrowLeft } from 'lucide-react';

export default function BookFinderPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchType, setSearchType] = useState('title');
  const [books, setBooks] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const searchBooks = useCallback(async () => {
    if (!searchQuery.trim()) return;
    
    setLoading(true);
    setError(null);
    
    try {
      let url = 'https://openlibrary.org/search.json?';
      
      switch (searchType) {
        case 'title':
          url += `title=${encodeURIComponent(searchQuery)}`;
          break;
        case 'author':
          url += `author=${encodeURIComponent(searchQuery)}`;
          break;
        case 'subject':
          url += `subject=${encodeURIComponent(searchQuery)}`;
          break;
        case 'isbn':
          url += `isbn=${encodeURIComponent(searchQuery)}`;
          break;
        default:
          url += `q=${encodeURIComponent(searchQuery)}`;
      }
      
      url += '&limit=20';
      
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`Search failed: ${response.status} ${response.statusText}`);
      }
      
      const data = await response.json();
      setBooks(data.docs || []);
    } catch (err) {
      console.error(err);
      setError('Failed to search books. Please try again.');
    } finally {
      setLoading(false);
    }
  }, [searchQuery, searchType]);

  const handleSubmit = (e) => {
    e.preventDefault();
    searchBooks();
  };

  const getCoverUrl = (book) => {
    if (book.cover_i) {
      return `https://covers.openlibrary.org/b/id/${book.cover_i}-M.jpg`;
    }
    return null;
  };

  const getBookUrl = (book) => {
    if (book.key) {
      return `https://openlibrary.org${book.key}`;
    }
    return null;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="container mx-auto px-4 py-8">
        {/* Navigation */}
        <div className="mb-6">
          <a href="/" className="inline-flex items-center gap-2 text-blue-600 hover:text-blue-800 font-medium">
            <ArrowLeft size={20} />
            Back to Apps
          </a>
        </div>

        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-800 mb-2 flex items-center justify-center gap-3">
            <Book className="text-blue-600" size={40} />
            Book Finder
          </h1>
          <p className="text-gray-600 text-lg">Discover your next great read, Alex!</p>
          <p className="text-sm text-blue-600 mt-2">Perfect for college research and leisure reading</p>
        </div>

        {/* Search Form */}
        <div className="max-w-2xl mx-auto mb-8">
          <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-lg p-6">
            <div className="flex flex-col md:flex-row gap-4 mb-4">
              <select
                value={searchType}
                onChange={(e) => setSearchType(e.target.value)}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="title">Title</option>
                <option value="author">Author</option>
                <option value="subject">Subject/Genre</option>
                <option value="isbn">ISBN</option>
                <option value="general">General Search</option>
              </select>
              
              <div className="flex-1 relative">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={`Search by ${searchType}...`}
                  className="w-full px-4 py-2 pl-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                <Search className="absolute left-3 top-2.5 text-gray-400" size={20} />
              </div>
              
              <button
                type="submit"
                disabled={loading || !searchQuery.trim()}
                className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                {loading ? 'Searching...' : 'Search'}
              </button>
            </div>
          </form>
        </div>

        {/* Quick Search Suggestions */}
        <div className="max-w-2xl mx-auto mb-8">
          <div className="text-center mb-4">
            <p className="text-sm text-gray-600">Popular searches for students:</p>
          </div>
          <div className="flex flex-wrap justify-center gap-2">
            {['Psychology', 'Computer Science', 'History', 'Mathematics', 'Literature', 'Biology'].map((subject) => (
              <button
                key={subject}
                onClick={() => {
                  setSearchType('subject');
                  setSearchQuery(subject);
                }}
                className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm hover:bg-blue-200 transition-colors"
              >
                {subject}
              </button>
            ))}
          </div>
        </div>

        {/* Error Message */}
        {error && (
          <div className="max-w-2xl mx-auto mb-6 p-4 bg-red-100 border border-red-300 rounded-lg text-red-700">
            {error}
          </div>
        )}

        {/* Results */}
        {books.length > 0 && (
          <div className="max-w-6xl mx-auto">
            <h2 className="text-2xl font-semibold text-gray-800 mb-6">
              Found {books.length} books
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {books.map((book, index) => (
                <div key={`${book.key}-${index}`} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
                  {/* Book Cover */}
                  <div className="h-64 bg-gray-200 flex items-center justify-center">
                    {getCoverUrl(book) ? (
                      <img
                        src={getCoverUrl(book)}
                        alt={book.title}
                        className="h-full w-auto object-cover"
                        onError={(e) => {
                          e.target.style.display = 'none';
                          e.target.nextSibling.style.display = 'flex';
                        }}
                      />
                    ) : null}
                    <div className="flex items-center justify-center h-full text-gray-400" style={{ display: getCoverUrl(book) ? 'none' : 'flex' }}>
                      <Book size={48} />
                    </div>
                  </div>
                  
                  {/* Book Info */}
                  <div className="p-4">
                    <h3 className="font-semibold text-gray-800 mb-2 line-clamp-2">
                      {book.title}
                    </h3>
                    
                    {book.author_name && (
                      <div className="flex items-center gap-1 text-sm text-gray-600 mb-2">
                        <User size={14} />
                        <span className="line-clamp-1">{book.author_name.join(', ')}</span>
                      </div>
                    )}
                    
                    {book.first_publish_year && (
                      <div className="flex items-center gap-1 text-sm text-gray-600 mb-2">
                        <Calendar size={14} />
                        <span>{book.first_publish_year}</span>
                      </div>
                    )}
                    
                    {book.ratings_average && (
                      <div className="flex items-center gap-1 text-sm text-gray-600 mb-3">
                        <Star size={14} className="text-yellow-500" />
                        <span>{book.ratings_average.toFixed(1)} ({book.ratings_count} ratings)</span>
                      </div>
                    )}
                    
                    {book.subject && book.subject.length > 0 && (
                      <div className="mb-3">
                        <div className="flex flex-wrap gap-1">
                          {book.subject.slice(0, 3).map((subject, idx) => (
                            <span
                              key={idx}
                              className="px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded-full"
                            >
                              {subject}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    {getBookUrl(book) && (
                      <a
                        href={getBookUrl(book)}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 text-blue-600 hover:text-blue-800 text-sm font-medium"
                      >
                        View Details
                        <ExternalLink size={14} />
                      </a>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* No Results */}
        {!loading && books.length === 0 && searchQuery && (
          <div className="text-center py-12">
            <Book className="mx-auto text-gray-400 mb-4" size={64} />
            <h3 className="text-xl font-medium text-gray-600 mb-2">No books found</h3>
            <p className="text-gray-500">Try searching with different keywords or search type</p>
          </div>
        )}

        {/* Welcome message if no search yet */}
        {!searchQuery && books.length === 0 && (
          <div className="text-center py-12">
            <Book className="mx-auto text-blue-400 mb-4" size={64} />
            <h3 className="text-xl font-medium text-gray-700 mb-2">Ready to find your next book?</h3>
            <p className="text-gray-500">Search by title, author, subject, or ISBN to get started</p>
          </div>
        )}
      </div>
    </div>
  );
}