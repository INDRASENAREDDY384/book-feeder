import { useState, useCallback } from 'react';
import { Search, ChefHat, Clock, Users, ArrowLeft, ExternalLink } from 'lucide-react';

export default function RecipePage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchType, setSearchType] = useState('ingredient');
  const [recipes, setRecipes] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const searchRecipes = useCallback(async () => {
    if (!searchQuery.trim()) return;
    
    setLoading(true);
    setError(null);
    
    try {
      let url = '';
      
      switch (searchType) {
        case 'ingredient':
          url = `https://www.themealdb.com/api/json/v1/1/filter.php?i=${encodeURIComponent(searchQuery)}`;
          break;
        case 'category':
          url = `https://www.themealdb.com/api/json/v1/1/filter.php?c=${encodeURIComponent(searchQuery)}`;
          break;
        case 'area':
          url = `https://www.themealdb.com/api/json/v1/1/filter.php?a=${encodeURIComponent(searchQuery)}`;
          break;
        case 'name':
          url = `https://www.themealdb.com/api/json/v1/1/search.php?s=${encodeURIComponent(searchQuery)}`;
          break;
        default:
          url = `https://www.themealdb.com/api/json/v1/1/search.php?s=${encodeURIComponent(searchQuery)}`;
      }
      
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`Search failed: ${response.status} ${response.statusText}`);
      }
      
      const data = await response.json();
      setRecipes(data.meals || []);
    } catch (err) {
      console.error(err);
      setError('Failed to search recipes. Please try again.');
    } finally {
      setLoading(false);
    }
  }, [searchQuery, searchType]);

  const getRandomRecipes = useCallback(async () => {
    setLoading(true);
    setError(null);
    
    try {
      const randomRecipes = [];
      // Get 12 random recipes
      for (let i = 0; i < 12; i++) {
        const response = await fetch('https://www.themealdb.com/api/json/v1/1/random.php');
        if (response.ok) {
          const data = await response.json();
          if (data.meals && data.meals[0]) {
            randomRecipes.push(data.meals[0]);
          }
        }
      }
      setRecipes(randomRecipes);
    } catch (err) {
      console.error(err);
      setError('Failed to get random recipes. Please try again.');
    } finally {
      setLoading(false);
    }
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    searchRecipes();
  };

  const getRecipeUrl = (recipe) => {
    if (recipe.strSource) {
      return recipe.strSource;
    }
    return `https://www.themealdb.com/meal/${recipe.idMeal}`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-100">
      <div className="container mx-auto px-4 py-8">
        {/* Navigation */}
        <div className="mb-6">
          <a href="/" className="inline-flex items-center gap-2 text-orange-600 hover:text-orange-800 font-medium">
            <ArrowLeft size={20} />
            Back to Apps
          </a>
        </div>

        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-800 mb-2 flex items-center justify-center gap-3">
            <ChefHat className="text-orange-600" size={40} />
            Recipe Ideas
          </h1>
          <p className="text-gray-600 text-lg">Quick meal ideas for your busy schedule, Taylor!</p>
          <p className="text-sm text-orange-600 mt-2">Perfect for busy professionals who want to cook at home</p>
        </div>

        {/* Search Form */}
        <div className="max-w-2xl mx-auto mb-8">
          <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-lg p-6">
            <div className="flex flex-col md:flex-row gap-4 mb-4">
              <select
                value={searchType}
                onChange={(e) => setSearchType(e.target.value)}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              >
                <option value="ingredient">By Ingredient</option>
                <option value="name">By Recipe Name</option>
                <option value="category">By Category</option>
                <option value="area">By Cuisine</option>
              </select>
              
              <div className="flex-1 relative">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={`Search ${searchType === 'ingredient' ? 'ingredients (e.g., chicken, rice)' : searchType === 'category' ? 'category (e.g., dessert, breakfast)' : searchType === 'area' ? 'cuisine (e.g., Italian, Mexican)' : 'recipe name'}...`}
                  className="w-full px-4 py-2 pl-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                />
                <Search className="absolute left-3 top-2.5 text-gray-400" size={20} />
              </div>
              
              <button
                type="submit"
                disabled={loading || !searchQuery.trim()}
                className="px-6 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                {loading ? 'Searching...' : 'Search'}
              </button>
            </div>
            
            <div className="text-center">
              <button
                type="button"
                onClick={getRandomRecipes}
                disabled={loading}
                className="px-4 py-2 bg-orange-100 text-orange-700 rounded-lg hover:bg-orange-200 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                {loading ? 'Loading...' : '🎲 Get Random Recipe Ideas'}
              </button>
            </div>
          </form>
        </div>

        {/* Quick Suggestions */}
        <div className="max-w-4xl mx-auto mb-8">
          <div className="text-center mb-4">
            <p className="text-sm text-gray-600">Quick ideas for busy professionals:</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-white rounded-lg p-4 text-center shadow">
              <h4 className="font-medium text-gray-800 mb-2">Quick Meals</h4>
              <div className="flex flex-wrap gap-1 justify-center">
                {['pasta', 'stir fry', 'sandwich'].map((item) => (
                  <button
                    key={item}
                    onClick={() => {
                      setSearchType('ingredient');
                      setSearchQuery(item);
                    }}
                    className="px-2 py-1 bg-orange-100 text-orange-700 rounded text-xs hover:bg-orange-200 transition-colors"
                  >
                    {item}
                  </button>
                ))}
              </div>
            </div>
            
            <div className="bg-white rounded-lg p-4 text-center shadow">
              <h4 className="font-medium text-gray-800 mb-2">Common Ingredients</h4>
              <div className="flex flex-wrap gap-1 justify-center">
                {['chicken', 'rice', 'eggs'].map((item) => (
                  <button
                    key={item}
                    onClick={() => {
                      setSearchType('ingredient');
                      setSearchQuery(item);
                    }}
                    className="px-2 py-1 bg-orange-100 text-orange-700 rounded text-xs hover:bg-orange-200 transition-colors"
                  >
                    {item}
                  </button>
                ))}
              </div>
            </div>
            
            <div className="bg-white rounded-lg p-4 text-center shadow">
              <h4 className="font-medium text-gray-800 mb-2">Meal Types</h4>
              <div className="flex flex-wrap gap-1 justify-center">
                {['breakfast', 'dinner', 'dessert'].map((item) => (
                  <button
                    key={item}
                    onClick={() => {
                      setSearchType('category');
                      setSearchQuery(item);
                    }}
                    className="px-2 py-1 bg-orange-100 text-orange-700 rounded text-xs hover:bg-orange-200 transition-colors"
                  >
                    {item}
                  </button>
                ))}
              </div>
            </div>
            
            <div className="bg-white rounded-lg p-4 text-center shadow">
              <h4 className="font-medium text-gray-800 mb-2">Cuisines</h4>
              <div className="flex flex-wrap gap-1 justify-center">
                {['Italian', 'Mexican', 'Asian'].map((item) => (
                  <button
                    key={item}
                    onClick={() => {
                      setSearchType('area');
                      setSearchQuery(item);
                    }}
                    className="px-2 py-1 bg-orange-100 text-orange-700 rounded text-xs hover:bg-orange-200 transition-colors"
                  >
                    {item}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Error Message */}
        {error && (
          <div className="max-w-2xl mx-auto mb-6 p-4 bg-red-100 border border-red-300 rounded-lg text-red-700">
            {error}
          </div>
        )}

        {/* Results */}
        {recipes.length > 0 && (
          <div className="max-w-6xl mx-auto">
            <h2 className="text-2xl font-semibold text-gray-800 mb-6">
              Found {recipes.length} recipes
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {recipes.map((recipe) => (
                <div key={recipe.idMeal} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
                  {/* Recipe Image */}
                  <div className="h-48 bg-gray-200">
                    <img
                      src={recipe.strMealThumb}
                      alt={recipe.strMeal}
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        e.target.style.display = 'none';
                        e.target.nextSibling.style.display = 'flex';
                      }}
                    />
                    <div className="flex items-center justify-center h-full text-gray-400 bg-gray-200" style={{ display: 'none' }}>
                      <ChefHat size={48} />
                    </div>
                  </div>
                  
                  {/* Recipe Info */}
                  <div className="p-4">
                    <h3 className="font-semibold text-gray-800 mb-2 line-clamp-2">
                      {recipe.strMeal}
                    </h3>
                    
                    <div className="flex items-center gap-4 text-sm text-gray-600 mb-3">
                      {recipe.strCategory && (
                        <span className="px-2 py-1 bg-orange-100 text-orange-700 rounded-full text-xs">
                          {recipe.strCategory}
                        </span>
                      )}
                      {recipe.strArea && (
                        <span className="px-2 py-1 bg-blue-100 text-blue-700 rounded-full text-xs">
                          {recipe.strArea}
                        </span>
                      )}
                    </div>
                    
                    {recipe.strInstructions && (
                      <p className="text-gray-600 text-sm mb-3 line-clamp-3">
                        {recipe.strInstructions.substring(0, 120)}...
                      </p>
                    )}
                    
                    <div className="flex items-center justify-between">
                      <a
                        href={getRecipeUrl(recipe)}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 text-orange-600 hover:text-orange-800 text-sm font-medium"
                      >
                        View Recipe
                        <ExternalLink size={14} />
                      </a>
                      
                      {recipe.strYoutube && (
                        <a
                          href={recipe.strYoutube}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="px-2 py-1 bg-red-100 text-red-700 rounded text-xs hover:bg-red-200 transition-colors"
                        >
                          📺 Video
                        </a>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* No Results */}
        {!loading && recipes.length === 0 && searchQuery && (
          <div className="text-center py-12">
            <ChefHat className="mx-auto text-gray-400 mb-4" size={64} />
            <h3 className="text-xl font-medium text-gray-600 mb-2">No recipes found</h3>
            <p className="text-gray-500">Try searching with different ingredients or terms</p>
          </div>
        )}

        {/* Welcome message if no search yet */}
        {!searchQuery && recipes.length === 0 && !loading && (
          <div className="text-center py-12">
            <ChefHat className="mx-auto text-orange-400 mb-4" size={64} />
            <h3 className="text-xl font-medium text-gray-700 mb-2">Ready to cook something delicious?</h3>
            <p className="text-gray-500">Search by ingredients you have, or get random recipe inspiration!</p>
          </div>
        )}
      </div>
    </div>
  );
}