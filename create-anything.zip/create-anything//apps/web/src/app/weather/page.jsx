import { useState, useCallback, useEffect } from 'react';
import { Search, Cloud, Sun, CloudRain, Thermometer, Wind, Droplets, Eye, ArrowLeft, MapPin } from 'lucide-react';

export default function WeatherPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [weatherData, setWeatherData] = useState(null);
  const [locationData, setLocationData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const searchWeather = useCallback(async () => {
    if (!searchQuery.trim()) return;
    
    setLoading(true);
    setError(null);
    
    try {
      // First, get coordinates for the city using a geocoding service
      const geoResponse = await fetch(
        `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(searchQuery)}&count=1&language=en&format=json`
      );
      
      if (!geoResponse.ok) {
        throw new Error('Failed to find location');
      }
      
      const geoData = await geoResponse.json();
      if (!geoData.results || geoData.results.length === 0) {
        throw new Error('City not found');
      }
      
      const location = geoData.results[0];
      setLocationData(location);
      
      // Then get weather data using the coordinates
      const weatherResponse = await fetch(
        `https://api.open-meteo.com/v1/forecast?latitude=${location.latitude}&longitude=${location.longitude}&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,rain,showers,snowfall,weather_code,cloud_cover,pressure_msl,surface_pressure,wind_speed_10m,wind_direction_10m,wind_gusts_10m&hourly=temperature_2m,relative_humidity_2m,dew_point_2m,apparent_temperature,precipitation_probability,precipitation,rain,showers,snowfall,snow_depth,weather_code,pressure_msl,surface_pressure,cloud_cover,visibility,evapotranspiration,et0_fao_evapotranspiration,vapour_pressure_deficit,wind_speed_10m,wind_speed_80m,wind_speed_120m,wind_speed_180m,wind_direction_10m,wind_direction_80m,wind_direction_120m,wind_direction_180m,wind_gusts_10m,temperature_80m,temperature_120m,temperature_180m,soil_temperature_0cm,soil_temperature_6cm,soil_temperature_18cm,soil_temperature_54cm,soil_moisture_0_1cm,soil_moisture_1_3cm,soil_moisture_3_9cm,soil_moisture_9_27cm,soil_moisture_27_81cm&daily=weather_code,temperature_2m_max,temperature_2m_min,apparent_temperature_max,apparent_temperature_min,sunrise,sunset,daylight_duration,sunshine_duration,uv_index_max,uv_index_clear_sky_max,precipitation_sum,rain_sum,showers_sum,snowfall_sum,precipitation_hours,precipitation_probability_max,wind_speed_10m_max,wind_gusts_10m_max,wind_direction_10m_dominant,shortwave_radiation_sum,et0_fao_evapotranspiration&timezone=auto`
      );
      
      if (!weatherResponse.ok) {
        throw new Error('Failed to fetch weather data');
      }
      
      const weather = await weatherResponse.json();
      setWeatherData(weather);
    } catch (err) {
      console.error(err);
      setError(err.message || 'Failed to get weather data. Please try again.');
    } finally {
      setLoading(false);
    }
  }, [searchQuery]);

  const handleSubmit = (e) => {
    e.preventDefault();
    searchWeather();
  };

  const getWeatherIcon = (weatherCode, isDay) => {
    // Weather code mapping from Open-Meteo documentation
    if (weatherCode <= 3) return <Sun className="text-yellow-500" size={32} />;
    if (weatherCode <= 48) return <Cloud className="text-gray-500" size={32} />;
    if (weatherCode <= 67) return <CloudRain className="text-blue-500" size={32} />;
    return <Cloud className="text-gray-500" size={32} />;
  };

  const getWeatherDescription = (weatherCode) => {
    const descriptions = {
      0: 'Clear sky',
      1: 'Mainly clear',
      2: 'Partly cloudy',
      3: 'Overcast',
      45: 'Fog',
      48: 'Depositing rime fog',
      51: 'Light drizzle',
      53: 'Moderate drizzle',
      55: 'Dense drizzle',
      56: 'Light freezing drizzle',
      57: 'Dense freezing drizzle',
      61: 'Slight rain',
      63: 'Moderate rain',
      65: 'Heavy rain',
      66: 'Light freezing rain',
      67: 'Heavy freezing rain',
      71: 'Slight snow fall',
      73: 'Moderate snow fall',
      75: 'Heavy snow fall',
      77: 'Snow grains',
      80: 'Slight rain showers',
      81: 'Moderate rain showers',
      82: 'Violent rain showers',
      85: 'Slight snow showers',
      86: 'Heavy snow showers',
      95: 'Thunderstorm',
      96: 'Thunderstorm with slight hail',
      99: 'Thunderstorm with heavy hail'
    };
    return descriptions[weatherCode] || 'Unknown';
  };

  const getCurrentLocation = () => {
    if (navigator.geolocation) {
      setLoading(true);
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          try {
            const { latitude, longitude } = position.coords;
            
            // Get location name from coordinates
            const geoResponse = await fetch(
              `https://geocoding-api.open-meteo.com/v1/search?latitude=${latitude}&longitude=${longitude}&count=1&language=en&format=json`
            );
            
            const weatherResponse = await fetch(
              `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,rain,showers,snowfall,weather_code,cloud_cover,pressure_msl,surface_pressure,wind_speed_10m,wind_direction_10m,wind_gusts_10m&hourly=temperature_2m,relative_humidity_2m,dew_point_2m,apparent_temperature,precipitation_probability,precipitation,rain,showers,snowfall,snow_depth,weather_code,pressure_msl,surface_pressure,cloud_cover,visibility,evapotranspiration,et0_fao_evapotranspiration,vapour_pressure_deficit,wind_speed_10m,wind_speed_80m,wind_speed_120m,wind_speed_180m,wind_direction_10m,wind_direction_80m,wind_direction_120m,wind_direction_180m,wind_gusts_10m,temperature_80m,temperature_120m,temperature_180m,soil_temperature_0cm,soil_temperature_6cm,soil_temperature_18cm,soil_temperature_54cm,soil_moisture_0_1cm,soil_moisture_1_3cm,soil_moisture_3_9cm,soil_moisture_9_27cm,soil_moisture_27_81cm&daily=weather_code,temperature_2m_max,temperature_2m_min,apparent_temperature_max,apparent_temperature_min,sunrise,sunset,daylight_duration,sunshine_duration,uv_index_max,uv_index_clear_sky_max,precipitation_sum,rain_sum,showers_sum,snowfall_sum,precipitation_hours,precipitation_probability_max,wind_speed_10m_max,wind_gusts_10m_max,wind_direction_10m_dominant,shortwave_radiation_sum,et0_fao_evapotranspiration&timezone=auto`
            );
            
            if (weatherResponse.ok) {
              const weather = await weatherResponse.json();
              setWeatherData(weather);
              
              // Try to get location name, fallback to coordinates
              try {
                if (geoResponse.ok) {
                  const geoData = await geoResponse.json();
                  if (geoData.results && geoData.results.length > 0) {
                    setLocationData(geoData.results[0]);
                  }
                }
              } catch (e) {
                // Fallback to coordinates display
                setLocationData({
                  name: `${latitude.toFixed(2)}, ${longitude.toFixed(2)}`,
                  latitude,
                  longitude
                });
              }
            }
          } catch (err) {
            setError('Failed to get current location weather');
          } finally {
            setLoading(false);
          }
        },
        (error) => {
          setLoading(false);
          setError('Unable to get your location. Please search for a city manually.');
        }
      );
    } else {
      setError('Geolocation is not supported by this browser.');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 to-blue-100">
      <div className="container mx-auto px-4 py-8">
        {/* Navigation */}
        <div className="mb-6">
          <a href="/" className="inline-flex items-center gap-2 text-sky-600 hover:text-sky-800 font-medium">
            <ArrowLeft size={20} />
            Back to Apps
          </a>
        </div>

        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-800 mb-2 flex items-center justify-center gap-3">
            <Cloud className="text-sky-600" size={40} />
            Weather Now
          </h1>
          <p className="text-gray-600 text-lg">Current conditions for your outdoor adventures, Jamie!</p>
          <p className="text-sm text-sky-600 mt-2">Perfect for planning your next outdoor activity</p>
        </div>

        {/* Search Form */}
        <div className="max-w-2xl mx-auto mb-8">
          <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-lg p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Enter city name..."
                  className="w-full px-4 py-2 pl-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-transparent"
                />
                <Search className="absolute left-3 top-2.5 text-gray-400" size={20} />
              </div>
              
              <button
                type="submit"
                disabled={loading || !searchQuery.trim()}
                className="px-6 py-2 bg-sky-600 text-white rounded-lg hover:bg-sky-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                {loading ? 'Loading...' : 'Get Weather'}
              </button>
              
              <button
                type="button"
                onClick={getCurrentLocation}
                disabled={loading}
                className="px-4 py-2 bg-sky-100 text-sky-700 rounded-lg hover:bg-sky-200 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center gap-2"
              >
                <MapPin size={16} />
                Current Location
              </button>
            </div>
          </form>
        </div>

        {/* Error Message */}
        {error && (
          <div className="max-w-2xl mx-auto mb-6 p-4 bg-red-100 border border-red-300 rounded-lg text-red-700">
            {error}
          </div>
        )}

        {/* Weather Results */}
        {weatherData && locationData && (
          <div className="max-w-4xl mx-auto">
            {/* Current Weather */}
            <div className="bg-white rounded-lg shadow-lg p-6 mb-6">
              <div className="text-center mb-6">
                <h2 className="text-2xl font-bold text-gray-800 mb-1">{locationData.name}</h2>
                {locationData.country && (
                  <p className="text-gray-600">{locationData.country}</p>
                )}
              </div>
              
              <div className="flex flex-col md:flex-row items-center justify-center gap-8">
                <div className="text-center">
                  {getWeatherIcon(weatherData.current.weather_code, weatherData.current.is_day)}
                  <p className="mt-2 text-lg font-medium text-gray-700">
                    {getWeatherDescription(weatherData.current.weather_code)}
                  </p>
                </div>
                
                <div className="text-center">
                  <div className="text-5xl font-bold text-gray-800 mb-2">
                    {Math.round(weatherData.current.temperature_2m)}°C
                  </div>
                  <p className="text-gray-600">
                    Feels like {Math.round(weatherData.current.apparent_temperature)}°C
                  </p>
                </div>
              </div>
            </div>

            {/* Weather Details */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div className="bg-white rounded-lg shadow p-4 text-center">
                <Wind className="mx-auto text-sky-600 mb-2" size={24} />
                <p className="text-sm text-gray-600">Wind Speed</p>
                <p className="text-lg font-semibold">{weatherData.current.wind_speed_10m} km/h</p>
              </div>
              
              <div className="bg-white rounded-lg shadow p-4 text-center">
                <Droplets className="mx-auto text-blue-600 mb-2" size={24} />
                <p className="text-sm text-gray-600">Humidity</p>
                <p className="text-lg font-semibold">{weatherData.current.relative_humidity_2m}%</p>
              </div>
              
              <div className="bg-white rounded-lg shadow p-4 text-center">
                <Thermometer className="mx-auto text-red-600 mb-2" size={24} />
                <p className="text-sm text-gray-600">Pressure</p>
                <p className="text-lg font-semibold">{Math.round(weatherData.current.pressure_msl)} hPa</p>
              </div>
              
              <div className="bg-white rounded-lg shadow p-4 text-center">
                <Eye className="mx-auto text-gray-600 mb-2" size={24} />
                <p className="text-sm text-gray-600">Cloud Cover</p>
                <p className="text-lg font-semibold">{weatherData.current.cloud_cover}%</p>
              </div>
            </div>

            {/* 7-Day Forecast */}
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h3 className="text-xl font-bold text-gray-800 mb-4">7-Day Forecast</h3>
              <div className="grid grid-cols-1 md:grid-cols-7 gap-4">
                {weatherData.daily.time.slice(0, 7).map((date, index) => (
                  <div key={date} className="text-center p-3 border border-gray-200 rounded-lg">
                    <p className="text-sm font-medium text-gray-600 mb-2">
                      {index === 0 ? 'Today' : new Date(date).toLocaleDateString('en', { weekday: 'short' })}
                    </p>
                    {getWeatherIcon(weatherData.daily.weather_code[index], true)}
                    <div className="mt-2">
                      <p className="text-sm font-semibold text-gray-800">
                        {Math.round(weatherData.daily.temperature_2m_max[index])}°
                      </p>
                      <p className="text-xs text-gray-600">
                        {Math.round(weatherData.daily.temperature_2m_min[index])}°
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Welcome message if no search yet */}
        {!weatherData && !loading && (
          <div className="text-center py-12">
            <Cloud className="mx-auto text-sky-400 mb-4" size={64} />
            <h3 className="text-xl font-medium text-gray-700 mb-2">Ready to check the weather?</h3>
            <p className="text-gray-500">Enter a city name or use your current location to get started</p>
          </div>
        )}
      </div>
    </div>
  );
}