import { Book, Cloud, ChefHat, Globe, ArrowRight } from "lucide-react";

export default function HomePage() {
  const apps = [
    {
      id: "books",
      title: "Book Finder",
      description: "Search and discover books by title, author, genre, or ISBN",
      persona: "For Alex - College Student",
      icon: Book,
      color: "from-blue-500 to-blue-600",
      bgColor: "bg-blue-50",
      textColor: "text-blue-700",
      href: "/books",
    },
    {
      id: "weather",
      title: "Weather Now",
      description: "Check current weather conditions for any city worldwide",
      persona: "For Jamie - Outdoor Enthusiast",
      icon: Cloud,
      color: "from-sky-500 to-sky-600",
      bgColor: "bg-sky-50",
      textColor: "text-sky-700",
      href: "/weather",
    },
    {
      id: "recipes",
      title: "Recipe Ideas",
      description: "Find recipes based on ingredients, mood, or cooking time",
      persona: "For Taylor - Busy Professional",
      icon: ChefHat,
      color: "from-orange-500 to-orange-600",
      bgColor: "bg-orange-50",
      textColor: "text-orange-700",
      href: "/recipes",
    },
    {
      id: "earthquakes",
      title: "Earthquake Visualizer",
      description: "Visualize recent earthquake activity around the world",
      persona: "For Casey - Geography Student",
      icon: Globe,
      color: "from-red-500 to-red-600",
      bgColor: "bg-red-50",
      textColor: "text-red-700",
      href: "/earthquakes",
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-cyan-50">
      <div className="container mx-auto px-4 py-12">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-5xl font-bold text-gray-800 mb-4">
            App Collection
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Four specialized applications designed for different user needs.
            Choose the one that fits your requirements.
          </p>
        </div>

        {/* App Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-6xl mx-auto">
          {apps.map((app) => {
            const IconComponent = app.icon;
            return (
              <a key={app.id} href={app.href} className="block">
                <div
                  className={`${app.bgColor} rounded-2xl p-8 hover:shadow-xl transition-all duration-300 hover:-translate-y-1 cursor-pointer border border-white/50`}
                >
                  {/* Icon and Title */}
                  <div className="flex items-center gap-4 mb-4">
                    <div
                      className={`w-16 h-16 rounded-xl bg-gradient-to-r ${app.color} flex items-center justify-center shadow-lg`}
                    >
                      <IconComponent className="text-white" size={32} />
                    </div>
                    <div>
                      <h2 className="text-2xl font-bold text-gray-800">
                        {app.title}
                      </h2>
                      <p className={`text-sm font-medium ${app.textColor}`}>
                        {app.persona}
                      </p>
                    </div>
                  </div>

                  {/* Description */}
                  <p className="text-gray-600 mb-6 leading-relaxed">
                    {app.description}
                  </p>

                  {/* Call to Action */}
                  <div className="flex items-center justify-between">
                    <div
                      className={`inline-flex items-center gap-2 ${app.textColor} font-semibold`}
                    >
                      Launch App
                      <ArrowRight size={16} />
                    </div>
                  </div>
                </div>
              </a>
            );
          })}
        </div>

        {/* Footer */}
        <div className="text-center mt-16">
          <p className="text-gray-500">
            Each app is designed with a specific user persona in mind to provide
            the best experience.
          </p>
        </div>
      </div>
    </div>
  );
}
